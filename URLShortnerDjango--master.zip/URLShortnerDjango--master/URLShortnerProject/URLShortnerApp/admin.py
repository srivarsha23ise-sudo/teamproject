from django.contrib import admin
from URLShortnerApp.models import URLData

admin.site.register(URLData)