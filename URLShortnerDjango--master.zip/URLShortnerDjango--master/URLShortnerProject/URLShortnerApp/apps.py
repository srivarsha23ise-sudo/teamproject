from django.apps import AppConfig


class UrlshortnerappConfig(AppConfig):
    name = 'URLShortnerApp'
